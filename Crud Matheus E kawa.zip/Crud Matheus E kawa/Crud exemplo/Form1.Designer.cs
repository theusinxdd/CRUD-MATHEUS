﻿namespace Crud_exemplo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBoxNome = new TextBox();
            textBoxSobrenome = new TextBox();
            textBoxCurso = new TextBox();
            textBoxAno = new TextBox();
            textBoxIdade = new TextBox();
            textBoxRM = new TextBox();
            buttonSalvar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(139, 43);
            label1.Name = "label1";
            label1.Size = new Size(40, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(139, 77);
            label2.Name = "label2";
            label2.Size = new Size(68, 15);
            label2.TabIndex = 2;
            label2.Text = "Sobrenome";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(139, 111);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 3;
            label3.Text = "Curso";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(139, 145);
            label4.Name = "label4";
            label4.Size = new Size(29, 15);
            label4.TabIndex = 4;
            label4.Text = "Ano";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(139, 177);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 5;
            label5.Text = "Idade";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(139, 206);
            label6.Name = "label6";
            label6.Size = new Size(25, 15);
            label6.TabIndex = 6;
            label6.Text = "RM";
            // 
            // textBoxNome
            // 
            textBoxNome.Location = new Point(213, 40);
            textBoxNome.Name = "textBoxNome";
            textBoxNome.Size = new Size(218, 23);
            textBoxNome.TabIndex = 7;
            // 
            // textBoxSobrenome
            // 
            textBoxSobrenome.Location = new Point(213, 74);
            textBoxSobrenome.Name = "textBoxSobrenome";
            textBoxSobrenome.Size = new Size(218, 23);
            textBoxSobrenome.TabIndex = 8;
            // 
            // textBoxCurso
            // 
            textBoxCurso.Location = new Point(213, 108);
            textBoxCurso.Name = "textBoxCurso";
            textBoxCurso.Size = new Size(218, 23);
            textBoxCurso.TabIndex = 9;
            textBoxCurso.TextChanged += textBox1_TextChanged;
            // 
            // textBoxAno
            // 
            textBoxAno.Location = new Point(213, 142);
            textBoxAno.Name = "textBoxAno";
            textBoxAno.Size = new Size(218, 23);
            textBoxAno.TabIndex = 10;
            // 
            // textBoxIdade
            // 
            textBoxIdade.Location = new Point(213, 174);
            textBoxIdade.Name = "textBoxIdade";
            textBoxIdade.Size = new Size(218, 23);
            textBoxIdade.TabIndex = 11;
            // 
            // textBoxRM
            // 
            textBoxRM.Location = new Point(213, 203);
            textBoxRM.Name = "textBoxRM";
            textBoxRM.Size = new Size(218, 23);
            textBoxRM.TabIndex = 12;
            // 
            // buttonSalvar
            // 
            buttonSalvar.BackColor = Color.Red;
            buttonSalvar.ForeColor = Color.Lime;
            buttonSalvar.Location = new Point(228, 262);
            buttonSalvar.Name = "buttonSalvar";
            buttonSalvar.Size = new Size(99, 30);
            buttonSalvar.TabIndex = 13;
            buttonSalvar.Text = "Salvar";
            buttonSalvar.UseVisualStyleBackColor = false;
            buttonSalvar.Click += button1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Captura_de_tela_2026_10_20_121915;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonSalvar);
            Controls.Add(textBoxRM);
            Controls.Add(textBoxIdade);
            Controls.Add(textBoxAno);
            Controls.Add(textBoxCurso);
            Controls.Add(textBoxSobrenome);
            Controls.Add(textBoxNome);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBoxNome;
        private TextBox textBoxSobrenome;
        private TextBox textBoxCurso;
        private TextBox textBoxAno;
        private TextBox textBoxIdade;
        private TextBox textBoxRM;
        private Button buttonSalvar;
    }
}
